enum efp_result efp_read_potential(struct efp *, const char **);
