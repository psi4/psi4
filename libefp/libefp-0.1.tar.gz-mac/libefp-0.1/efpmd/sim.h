void sim_sp(struct efp *, const struct config *);
void sim_grad(struct efp *, const struct config *);
void sim_cg(struct efp *, const struct config *);
void sim_nve(struct efp *, const struct config *);
void sim_nvt(struct efp *, const struct config *);
