void parse_config(const char *, struct config *);
void free_config(struct config *);
